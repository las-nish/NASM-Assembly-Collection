# OE Knowledge Base

This is the repository for all the information about OE Programming Language, OE Standard Library and OE Compiler Tool Chain.

```
Development Start Date: 05 March 2022
Development Start Time: 05:32 P.M.
```